﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace lab_8
{
    internal abstract class employee
    {
        public string name;
        public int age;
        public double salary;

        public abstract void showEmployeeInfo();
        
    }
}
